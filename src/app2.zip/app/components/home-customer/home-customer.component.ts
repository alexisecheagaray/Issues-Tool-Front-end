import { Component, OnInit } from '@angular/core';
import { RequestService } from 'src/app/services/request.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home-customer',
  templateUrl: './home-customer.component.html',
  styleUrls: ['./home-customer.component.scss'],
  providers: [RequestService],
})
export class HomeCustomerComponent implements OnInit {
  public requests: any;
  public count: any;

  constructor(
    private _requestService: RequestService,
    private _router: Router
  ) {}

  ngOnInit(): void {
    this.getRequests();
  }

  getRequests() {
    this.count = 0;

    this._requestService.getRequests().subscribe(
      (response) => {
        this.requests = response;
        this.count = this.requests.length;
        
        console.log('Those are the requests: ', this.requests);
      },
      (error) => {}
    );
  }
  
}
