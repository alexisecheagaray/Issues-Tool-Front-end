import { Component, OnInit } from '@angular/core';
import { RequestService } from 'src/app/services/request.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-home-support-department',
  templateUrl: './home-support-department.component.html',
  styleUrls: ['./home-support-department.component.scss']
})

export class HomeSupportDepartmentComponent implements OnInit {
  public requests: any;
  public count: any;

  constructor(
    private _requestService: RequestService,
    private _router: Router
  ) {}

  ngOnInit(): void {
    this.getRequests();
  }

  getRequests() {
    this.count = 0;

    this._requestService.getRequests().subscribe(
      (response) => {
        this.requests = response;
        this.count = this.requests.length;
        
        console.log('Those are the requests: ', this.requests);
      },
      (error) => {}
    );
  }
  
}

