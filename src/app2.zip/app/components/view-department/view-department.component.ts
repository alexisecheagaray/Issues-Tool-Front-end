import { Component, OnInit } from '@angular/core';
import { RequestService } from 'src/app/services/request.service';
import { FormBuilder, FormGroup, ReactiveFormsModule } from "@angular/forms"
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-view-department',
  templateUrl: './view-department.component.html',
  styleUrls: ['./view-department.component.css'],
  providers: [RequestService]
})
export class ViewDepartmentComponent implements OnInit {
  public department : any;
  constructor(
    private _requestService: RequestService,
    private _router: Router
  ) { }

  ngOnInit(): void {
    this.getDepartment();
  }

  getDepartment(){
    this._requestService.getDepartment().subscribe(
      response => {
        this.department = response;
        console.log("This are the departments: ", this.department);
      },
      error => {
      }
      );
  }

  delete(id){
    this._requestService.deleteDepartment(id).subscribe(
      response => {
        alert(response)
        window.location.reload();
      },
      error => {
      }
      );
  }

}
