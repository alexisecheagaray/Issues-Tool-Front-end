import { Component, OnInit } from '@angular/core';
import { RequestService } from 'src/app/services/request.service';
import { FormBuilder, FormGroup, ReactiveFormsModule } from "@angular/forms"
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-view-problem-type',
  templateUrl: './view-problem-type.component.html',
  styleUrls: ['./view-problem-type.component.css'],
  providers: [RequestService]
})
export class ViewProblemTypeComponent implements OnInit {
  public problemTypes : any;
  public updateProblemForm : any;

  constructor(
    private _requestService: RequestService,
    private _router: Router,
    public fb: FormBuilder
  ) { 
    this.updateProblemForm = this.fb.group({
      name : '',
      description: ''
    })
  }

  public update_problemType = {
    "name": "",
    "description": ""
  }

  ngOnInit(): void {
    this.getProblemType();
  }

  getProblemType(){
    this._requestService.getProblemType().subscribe(
      response => {
        this.problemTypes = response;
        console.log("This are the problems types: ", this.problemTypes);
      },
      error => {
      }
      );
  }

  updateProblemType(){
    this.update_problemType.name         = this.updateProblemForm.value.name;
    this.update_problemType.description  = this.updateProblemForm.value.description;
    
    console.log(this.update_problemType.name, this.update_problemType.description);

    this._requestService.updateProblemType(this.update_problemType).subscribe(
      response => {
        alert(response);
        window.location.reload();
      },
      error => {
      }
    );
  }

  delete(id){
    this._requestService.deleteProblemType(id).subscribe(
      response => {
        alert(response)
        window.location.reload();
      },
      error => {
      }
      );
  }
}
