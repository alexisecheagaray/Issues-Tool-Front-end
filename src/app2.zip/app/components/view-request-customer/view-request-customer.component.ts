import { Component, OnInit } from '@angular/core';
import { RequestService } from 'src/app/services/request.service';
import { FormBuilder, FormGroup, ReactiveFormsModule } from "@angular/forms"
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-view-request-customer',
  templateUrl: './view-request-customer.component.html',
  styleUrls: ['./view-request-customer.component.scss'],
  providers: [RequestService]
})
export class ViewRequestCustomerComponent implements OnInit {
  public requestsUser: any;
  
  constructor(
    private _requestService: RequestService,
    private _router: Router
  ) {}

  ngOnInit(): void {
    this.getRequestsUser();
  }
  
  getRequestsUser() {
    this._requestService.getRequestsUser().subscribe(
      (response) => {
        this.requestsUser = response;
        console.log('Those are the requests', this.requestsUser);
      },
      (error) => {}
    );
  }

}


