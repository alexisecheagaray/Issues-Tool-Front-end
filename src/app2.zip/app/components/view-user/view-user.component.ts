import { Component, OnInit } from '@angular/core';
import { RequestService } from 'src/app/services/request.service';
import { FormBuilder, FormGroup, ReactiveFormsModule } from "@angular/forms"
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { stringify } from 'querystring';

@Component({
  selector: 'app-view-user',
  templateUrl: './view-user.component.html',
  styleUrls: ['./view-user.component.css'],
  providers: [RequestService]
})
export class ViewUserComponent implements OnInit {
  public users : any;
  constructor(
    private _requestService: RequestService,
    private _router: Router
  ) { }

  ngOnInit(): void {
    this.getUsers();
    this.searchUsers( this.users );
  }

  saludo(){
    console.log("hello Mada", this.users);
  }

  searchUsers( buscar: string ) {

    this.users = [ { "email": "alexis@gmail.com", "first_name": "Alexis" } ];

    //this._requestService.searchUsers( buscar ).subscribe(
    //  response => {
    //     this.users = response;
    //  },
    //  error => {
    //  }
    //  );
  }

  getUsers(){
    this._requestService.getUsers().subscribe(
      response => {
         this.users = response;
        //alert( JSON.stringify( this.users ) );
        //this.users = [ { "email": "alexis@gmail.com", "first_name": "Alexis" } ];
        console.log("hello users", this.users);
      },
      error => {
      }
      );
  }

  delete(id){
    this._requestService.deleteUser(id).subscribe(
      response => {
        alert(response)
        window.location.reload();
      },
      error => {
      }
      );
  }

}
