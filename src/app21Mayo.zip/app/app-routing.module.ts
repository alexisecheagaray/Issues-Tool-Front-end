import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

              ////////////////////    ADMIN  ////////////////////////////
//User
import { CreateUserComponent } from './components/create-user/create-user.component';
import { ViewUserComponent } from './components/view-user/view-user.component';
//Home
import { HomeComponent } from './components/home/home.component';
//Department
import { CreateDepartmentComponent } from './components/create-department/create-department.component';
import { ViewDepartmentComponent } from './components/view-department/view-department.component';
//Request
import { CreateRequestComponent } from './components/create-request/create-request.component';
import { ViewRequestComponent } from './components/view-request/view-request.component';

//Problem Type
import { CreateProblemTypeComponent } from './components/create-problem-type/create-problem-type.component';
import { ViewProblemTypeComponent } from './components/view-problem-type/view-problem-type.component';

//Login
import { LoginComponent } from './components/login/login.component';
import { ConfigurationComponent } from './components/configuration/configuration.component';

            ////////////////////    CUSTOMER  ////////////////////////////
//Home
import { HomeCustomerComponent } from './components/home-customer/home-customer.component';
//View Request
import { ViewRequestCustomerComponent } from './components/view-request-customer/view-request-customer.component';
import { CreateRequestCustomerComponent } from './components/create-request-customer/create-request-customer.component';

            ////////////////////    SUPPORT DEPARTMENT  ////////////////////////////
//Home
import { HomeSupportDepartmentComponent } from './components/home-support-department/home-support-department.component';


const routes: Routes = [

  ////////////////////    ADMIN  ////////////////////////////  
  //Users
  { path: 'create-user',        component: CreateUserComponent},
  { path: 'view-user',          component: ViewUserComponent},

  //Department
  { path: 'create-department',  component: CreateDepartmentComponent},
  { path: 'view-department',    component: ViewDepartmentComponent},

  //Request
  { path: 'create-request',     component: CreateRequestComponent},
  { path: 'view-request',       component: ViewRequestComponent},

  //Problem Type
  { path: 'create-problem-type', component: CreateProblemTypeComponent},
  { path: 'view-problem-type',   component: ViewProblemTypeComponent},
  
 //HOME
  { path: 'home',       component: HomeComponent},
  {
    path: '',
    redirectTo: '/home',
    pathMatch: 'full'
  },

  //Extras
  { path: 'login', component: LoginComponent},
  { path: 'configuration', component: ConfigurationComponent},


  ////////////////////    CUSTOMER  ////////////////////////////
  //Home
  { path: 'home-customer',       component: HomeCustomerComponent},
  //Request Customer
  { path: 'view-request-customer', component: ViewRequestCustomerComponent},
  { path: 'create-request-customer', component: CreateRequestCustomerComponent},

  ////////////////////    SUPPORT DEPARTMENT  ////////////////////////////
  //Home
  { path: 'home-support-department', component: HomeSupportDepartmentComponent},
  
   
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
