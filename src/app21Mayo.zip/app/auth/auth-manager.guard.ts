import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class AuthManagerGuard implements CanActivate {
  public route_str_manager: any;
  constructor(
    private login_service: AuthService,
    private _router: Router 
  ){

  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean{
    console.log("Entro a revisar manager");

    console.log(this.login_service.isLoggedIn, this.login_service.typeUser);
    let typeUser = localStorage.getItem('type');
    let isLoggedIn = Boolean(localStorage.getItem('isLogin'));


    if(isLoggedIn && typeUser === "manager"){
      console.log("Entro al if");
      return true;  
    }
    
    localStorage.setItem("route", state.url);
    this.login_service.redirectUrl=state.url;
    this._router.navigate(['/login']);
    return false;
  }
  
}
