import { Injectable } from '@angular/core';
import { RequestService } from 'src/app/services/request.service';
import { tap } from 'rxjs/operators'
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  isLoggedIn = false;
  redirectUrl: string;
  typeUser: string;
  route_str_administrator: string;
  route_str_manager: string;

  constructor(
    private _requestService: RequestService, private _router: Router
  ) { 
    this.typeUser = localStorage.getItem('type');
    this.isLoggedIn = Boolean(localStorage.getItem('isLogin'));
    this.route_str_administrator = "/administration";
    this.route_str_manager = "";
  }

  login(user :string,password : string): any {
    return this._requestService.login(user,password).pipe(
    
      tap(response => {
        if(response === 'manager'){
          this.isLoggedIn = true;
          
          localStorage.setItem('type','manager');
          localStorage.setItem('isLogin','true');
          this.typeUser = "manger";

          this.route_str_manager = localStorage.getItem("route");
          
          if(this.route_str_manager !== ""){
            this._router.navigate([this.route_str_manager]);
          }
        }else if(response === 'admin'){
          this.typeUser = "admin";
          localStorage.setItem('isLogin','true');
          this.isLoggedIn = true;
          localStorage.setItem('type',"admin");
          this._router.navigate([this.route_str_administrator]);
        }
      })
    );
  }
}
