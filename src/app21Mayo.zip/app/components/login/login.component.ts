import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule } from "@angular/forms"
import { Router } from '@angular/router';

//NUEVOS
import { ActivatedRoute } from '@angular/router';
import { AuthService } from 'src/app/auth/auth.service';
import { AuthGuard } from 'src/app/auth/auth.guard';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  //providers: [RequestService]
  providers: [AuthService]
})

export class LoginComponent implements OnInit {
  public new_user : any;
  public route_str_administrator;
  public route_str_manager: any;
  public route_save: any;
 
    constructor(
      private _requestService: AuthService, private activateRoute: ActivatedRoute,private _router: Router
    ) { 
        this.new_user = {
          "user" : "",
          "password" : ""
        }
        this.route_str_administrator = "/administration";
        this.route_str_manager = "";
    }

    public loginUser={
      "user": "",
      "password": ""
    }

  ngOnInit(): void {
  }

  login(form){
    this.new_user["user"] = form.user;
    this.new_user["password"] = form.password;
    console.log("Usuario: ", this.new_user["user"]);
    console.log("Constraseña: ", this.new_user["password"]);
    
    this._requestService.login(this.new_user["user"],this.new_user["password"]).subscribe();
  }

}
