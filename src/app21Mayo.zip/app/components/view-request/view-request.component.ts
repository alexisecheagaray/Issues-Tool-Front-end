import { Component, OnInit } from '@angular/core';
import { RequestService } from 'src/app/services/request.service';
import { FormBuilder, FormGroup, ReactiveFormsModule } from "@angular/forms"
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-view-request',
  templateUrl: './view-request.component.html',
  styleUrls: ['./view-request.component.css'],
  providers: [RequestService]
})
export class ViewRequestComponent implements OnInit {
  public requests: any;
  constructor(
    private _requestService: RequestService,
    private _router: Router
  ) {}

  ngOnInit(): void {
    this.getRequests();
  }
  
  getRequests() {
    this._requestService.getRequests().subscribe(
      (response) => {
        this.requests = response;
        console.log('Those are the requests', this.requests);
      },
      (error) => {}
    );
  }

}
