import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable()
export class RequestService{
	public url: string;
	constructor(public _http : HttpClient){
		this.url = environment.url;
    }
    
    login(user, password){
      let headers = new HttpHeaders().set('Authorization','Basic ' + btoa("root:123456"));
      return this._http.get(this.url+'loginUser/'+user+'/'+password, {headers:headers});
    }
    
    getAdminSupport(): Observable<any>{
        let headers = new HttpHeaders().set('Authorization','Basic ' + btoa("root:123456"));
            return this._http.get(this.url+'list_admin_support/', {headers:headers});
    }

                               //////// VIEW //////////

    //View User
    getUsers(): Observable<any>{
        let headers = new HttpHeaders().set('Authorization','Basic ' + btoa("root:123456"));
            return this._http.get(this.url+'list_user/', {headers:headers});
    }

    //View User
    searchUsers( buscar: string ): Observable<any>{
      let headers = new HttpHeaders().set('Authorization','Basic ' + btoa("root:123456"));
          return this._http.get(this.url+'list_user?search=' + buscar, {headers:headers});
    }

    //View Department
    getDepartment(): Observable<any>{
        let headers = new HttpHeaders().set('Authorization','Basic ' + btoa("root:123456"));
            return this._http.get(this.url+'list_department/', {headers:headers});
    }

    //View Request
    getRequests(): Observable<any>{
      let headers = new HttpHeaders().set('Authorization','Basic ' + btoa("root:123456"));
          return this._http.get(this.url+'list_request/', {headers:headers});
    }

    //View Tickets Count
    getTicketCount(): Observable<any>{
      let headers = new HttpHeaders().set('Authorization','Basic ' + btoa("root:123456"));
          return this._http.get(this.url+'get_all_number_request/', {headers:headers});
    }

    //View Problem Type
    getProblemType(): Observable<any>{
      let headers = new HttpHeaders().set('Authorization','Basic ' + btoa("root:123456"));
          return this._http.get(this.url+'list_problem_type/', {headers:headers});
    }


    /////////////////////////CUSTOMER
    //View Request User
    getRequestsUser(): Observable<any>{
      let headers = new HttpHeaders().set('Authorization','Basic ' + btoa("root:123456"));
          return this._http.get(this.url+'get_request_user/', {headers:headers});
    }


                                ////////  CREATE /////////// 
    
    //Create a User
    createNewUser(user): Observable<any>{
        let params = JSON.stringify(user);
        let headers = new HttpHeaders().set(
          'Authorization',
          'Basic ' + btoa('root:123456')
          );
          return this._http.post(this.url+'new_user/', params, {headers:headers});
    }

    //Create a Request
    createRequest(request): Observable<any> {
      let params = JSON.stringify(request);
      let headers = new HttpHeaders().set(
        'Authorization',
        'Basic ' + btoa('root:123456')
      );
      return this._http.post(this.url + 'new_request/', params, {
        headers: headers,
      });
    }

    //Create a Department
    createDepartment(department): Observable<any> {
      let params = JSON.stringify(department);
      let headers = new HttpHeaders().set(
        'Authorization',
        'Basic ' + btoa('root:123456')
      );
      return this._http.post(this.url + 'new_department/', params, {
        headers: headers,
      });
    }

    //Create a Problem Type
    createProblemType(problemType): Observable<any> {
      let params = JSON.stringify(problemType);
      let headers = new HttpHeaders().set(
        'Authorization',
        'Basic ' + btoa('root:123456')
      );
      return this._http.post(this.url + 'new_problem_type/', params, {
        headers: headers,
      });
    }

    getInformation(){
      return this._http.get(environment.loginData);
    }

    /////////////////////////CUSTOMER
    

                            ///////// DELETE ////////

    deleteUser(id): Observable<any>{
        let headers = new HttpHeaders().set('Authorization','Basic ' + btoa("root:123456"));
        return this._http.get(this.url+'delete_user/'+ id, {headers:headers});
    }

    deleteDepartment(id): Observable<any>{
      let headers = new HttpHeaders().set('Authorization','Basic ' + btoa("root:123456"));
      return this._http.get(this.url+'delete_department/'+ id, {headers:headers});
    }

    deleteProblemType(id): Observable<any>{
      let headers = new HttpHeaders().set('Authorization','Basic ' + btoa("root:123456"));
      return this._http.get(this.url+'delete_problem_type/'+ id, {headers:headers});
    }

                            ///////// UPDATE ////////
    updateProblemType(problemType): Observable<any> {
      let params = JSON.stringify(problemType);
      let headers = new HttpHeaders().set(
        'Authorization',
        'Basic ' + btoa('root:123456')
      );
      return this._http.post(this.url + 'update_problem_type/', params, {
        headers: headers,
      });
    }    
    
}